declare const binaryExtensionsJson: readonly string[];

export = binaryExtensionsJson;
