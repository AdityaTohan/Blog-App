module.exports = require('./lib/deep-extend');
