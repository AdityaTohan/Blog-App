'use strict'

var names = require('./');
var assert = require('assert');

assert.deepEqual(names.red, [255,0,0]);
assert.deepEqual(names.aliceblue, [240,248,255]);
